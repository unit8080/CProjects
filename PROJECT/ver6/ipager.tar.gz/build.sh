#!/bin/sh
gcc main.c timer.c hash.c list.c readInputFile.c -Wall -o2 -o ipager
